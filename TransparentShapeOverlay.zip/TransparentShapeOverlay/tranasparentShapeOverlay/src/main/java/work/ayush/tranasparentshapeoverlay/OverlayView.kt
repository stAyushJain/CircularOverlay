package work.ayush.tranasparentshapeoverlay


import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import android.graphics.RectF

import android.R.attr.centerX
import android.annotation.SuppressLint
import android.content.res.Resources
import android.util.TypedValue
import android.view.View.MeasureSpec


class OverlayView: View {

        private lateinit var mTransparentPaint: Paint
        private lateinit var mRecPaint: Paint
        private lateinit var mProgressPaint: Paint
        private var swipeAngle = 0f
        private var progress = 1
        private val mPath: Path = Path()
    private lateinit var mRectF: RectF

        constructor(context: Context?) : super(context) {
            initPaints()
        }

        constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
            initPaints()
        }

        constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
            context,
            attrs,
            defStyleAttr
        ) {
            initPaints()
        }

        private fun initPaints() {
            mTransparentPaint = Paint()
            mTransparentPaint.setColor(Color.TRANSPARENT)

            mRecPaint = Paint()
            mRecPaint.setColor(ContextCompat.getColor(context, R.color.trans_black))

            mProgressPaint = Paint()
            mProgressPaint.setColor(ContextCompat.getColor(context, R.color.progress_blue))
            mProgressPaint.setStrokeWidth(10.toPx)
            mProgressPaint.style = Paint.Style.STROKE


        }

    @SuppressLint("DrawAllocation")
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val viewWidth = MeasureSpec.getSize(widthMeasureSpec)
        val viewHeight = MeasureSpec.getSize(heightMeasureSpec)

        val smallCirclRadius = viewWidth/2 - 150 + 10.toPx

        val centerX = viewWidth / 2f
        val centerY = viewHeight / 2f
        mRectF = RectF(
            centerX - smallCirclRadius,
            centerY - smallCirclRadius,
            centerX + smallCirclRadius,
            centerY + smallCirclRadius
        )
    }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
                mPath.reset()
                mPath.addCircle(
                    canvas.getWidth() / 2f,
                    canvas.getHeight() / 2f,
                    (canvas.getWidth() / 2f) - 150,
                    Path.Direction.CW
                )
                mPath.setFillType(Path.FillType.INVERSE_EVEN_ODD)

                canvas.drawPath(mPath, mTransparentPaint)
                canvas.clipPath(mPath)

                canvas.drawRect(
                    0f,
                    0f,
                    canvas.getWidth().toFloat(),
                    canvas.height.toFloat(),
                    mRecPaint
                )
                canvas.drawColor(Color.TRANSPARENT)

            canvas.drawArc(mRectF, 270f, swipeAngle, false, mProgressPaint)
        }

    fun setProgress(progress: Int) {
        this.progress = progress
        val percentage: Int = progress * 100 / 4
        swipeAngle = percentage * 360 / 100f
        invalidate()
    }

    val Int.toPx get() = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        this.toFloat(),
        Resources.getSystem().displayMetrics)
}